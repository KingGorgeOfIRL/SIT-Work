/*
 * Random access file example.
 */
#include <stdio.h>

/* this structure holds the data for one client */
typedef struct client_struct {
    int acc_num;
    char last_name[15];
    char first_name[10];
    double balance;
} Client;

int main() {

	const char *filename = "random_access_write.dat";
	FILE *f;
	Client client;

	/* open the data file */
	f = fopen(filename, "rb");
	if (f == NULL) {
		printf("Could not open %s.\n", filename);
		return;
	}
	/* print title */
	printf("%-6s%-16s%-11s%10s\n", "Acct", "Last Name", "First Name", "Balance");
	/* read one record at a time until we reach EOF */
	fread(&client, sizeof(Client), 1, f);
	while (!feof(f)) {
		if (client.acc_num != 0)
			printf("%-6d%-16s%-11s%10.2lf\n", client.acc_num, client.last_name, client.first_name, client.balance);
		fread(&client, sizeof(Client), 1, f);
	}
	fclose(f);
}
