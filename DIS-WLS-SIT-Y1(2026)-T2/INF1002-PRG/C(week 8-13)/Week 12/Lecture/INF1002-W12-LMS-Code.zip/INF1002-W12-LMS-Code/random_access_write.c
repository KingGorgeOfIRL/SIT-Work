#include <stdio.h>
/* this structure holds the data for one client */
typedef struct client_struct {
    int acc_num;
    char last_name[15];
    char first_name[10];
    double balance;
} Client;

int main() {
	const char *filename = "random_access_write.dat";
	FILE *f;
	Client client;
	/* open the data file */
	f = fopen(filename, "wb+");
	if (f == NULL) {
		printf("Could not open %s.\n", filename);
		return;
	}
	/* read account data from the user */
	printf("Enter account number (1-100, 0 to end)\n? ");
	scanf("%d", &client.acc_num);
	while (client.acc_num != 0) {
		/* read the data for this record */
		printf("Enter last_name first_name balance\n? ");
		scanf("%14s%9s%lf", client.last_name, client.first_name, &client.balance);
		/* go to this record's position in the file */
		fseek(f, (client.acc_num - 1) * sizeof(Client), SEEK_SET);
		/* write the client data structure */
		fwrite(&client, sizeof(Client), 1, f);
		/* ask for another record */
		printf("Enter account number (1-100, 0 to end)\n? ");
		scanf("%d", &client.acc_num);
	}
	fclose(f);
	return 0;
}
