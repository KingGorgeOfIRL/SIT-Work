r'''
Task Description:
In this task, you are going to design one program to check the popular characters
in a given string. You need to write one program to calculate the top 5 most 
frequent characters. The following are some hints that may help you design this program. 
	. String has a cool function that you can use to return a copy of the string 
     in which all case-based characters have been lowercased. 
	. To get the top 5 most frequent characters after sorting them, you need to 
     extract all the characters first and figure out one way to calculate the frequency 
     of each character. Then select the top 5 characters. 
	. The output must in the descending order of character frequency. If there are 
     characters with the same frequency, they must be printed in ascending ASCII order.
	. Print out the top 5 characters and their counts in the screen. (Your output should be in one line)

Running Examples:
C:\INF1002\Lab2\CountPopularChars>python CountPopularChars.py sdsERwweYxcxeewHJesddsdskjjkjrFGe21DS2145o9003gDDS
d:7,s:7,e:6,j:4,w:3
'''
import sys

def CountPopularChars():
    # Get input string from command line
    if len(sys.argv) < 2:
        return

    s = sys.argv[1].lower()  # convert to lowercase

    # Count frequency of each character
    freq = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1

    # Sort by:
    # 1. descending frequency
    # 2. ascending ASCII order of character
    sorted_chars = sorted(freq.items(), key=lambda x: (-x[1], x[0]))

    # Take top 5
    top5 = sorted_chars[:5]

    # Format output
    output = ",".join(f"{ch}:{count}" for ch, count in top5)
    print(output)

if __name__ == '__main__':
    CountPopularChars()

      
