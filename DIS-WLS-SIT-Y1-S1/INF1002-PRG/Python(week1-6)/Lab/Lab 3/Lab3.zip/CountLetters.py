r'''
Task Description:
      In this task, you are going to develop a letter game to count the number of leters
      in the given string.
      Step1:
            Write one functon leter_count(str) that take in one word and returns a dictonary 
            with the frequency counts of the various letters. Upper and lower-case characters 
            are different characters.
            Sample executon:
                  >>letter_count('This')
                  { 'h':1, 'T':1, 'i':1, 's':1}
                  >>letter_count('Thisisit')
                  {'h':1, 'T':1, 'i':3, 's':2, 't':1}
      Step 2:
            Write one functon double_count(str1, str2) that takes in two words and returns a 
            dictonary with the frequency counts of the various le􀆩ers. Upper and lower-case 
            characters are different characters.
            Sample executon:
                  >> double_count('This', 'isit')
                  {'h':1, 'T':1, 'i':3, 's':2, 't':1}
      Step 3:
            Write one functon various_count(*str) that takes in any number of words and returns 
            a dictonary with the frequency counts of the various le􀆩ers. Upper and lower-case 
            characters are different characters.
            Sample execu􀆟on:
                  >> various_count('This')
                  { 'h':1, 'T':1, 'i':1, 's':1}
                  >> various_count('This', 'isit')
                  {'h':1, 'T':1, 'i':3, 's':2, 't':1}
                  >> various_count('This', 'is, 'it')
                  {'h':1, 'T':1, 'i':3, 's':2, 't':1}
            HINT: In Python, using “def func(*str): list1=str”, list1 can obtain any number of 
            arguments and stores it as a list. You can further get each element from the list 
            and count each word independently. You can implement another func􀆟on to merge two 
            dictonaries. 
            Below is an example:
                  >> def str1(*str)
                        list = str
                        print list
                  >> str1('This', 'is', 'so', 'cool')
                  ('This', 'is', 'so', 'cool')

      Step 4:
            Write one program to allow users to input different number of words and output each
            character's frequency.
            Some of codes read as follows. Please print your results in the characters' ASCII 
            descending order according to this format:

            for item in sorted_total:
            print ('%s:%d' % (item, total[item]), end=' ')

            Note that the following running example is in ONE line, and your output should be in ONE line.

      Running example:
      C:\INF1002\Lab3\CountingLetters>python CountLetters.py Firefox,is,having,trouble,recovering,your,windows,and,tabs
      y:1 x:1 w:2 v:2 u:2 t:2 s:3 r:5 o:5 n:4 l:1 i:5 h:1 g:2 f:1 e:4 d:2 c:1 b:2 a:3 F:1

'''
import sys

# you can use sys.argv[1] to get the first input argument.
# sys.argv[2] is the second argument, etc.

#1
def letter_count(tmpStr):
      count_dir = {}
      for i in tmpStr:
            if i in count_dir:
                  count_dir[i] += 1
            else:
                  count_dir[i] = 1
      return count_dir

#2 this function, there are two input arguments: two strings
def double_count(str1, str2):
      count_dir = {}
      for string in (str1,str2):
            count_dir.update(letter_count(string))
      return count_dir

#3 This one takes only one input argument
def various_counts(*tmpStr):
      word_list = tmpStr
      count_dir = {}
      for string in word_list[0]:
            count_dir.update(letter_count(string))
      return count_dir

def CountLetters():
      item = sys.argv[1]
      words = item.split(',')
      count_dir = {}
      for word in words:
            for letter in word:
                  if letter in count_dir:
                        count_dir[letter] += 1
                  else:
                        count_dir[letter] = 1
      reverse = sorted(count_dir.items(),reverse=True)
      for item in reverse:
            print ('%s:%d' % (item[0], item[1]), end=' ')
if __name__=='__main__':
      CountLetters()
      



