/*
 * main.js
 * 
 * INF1005 - Web Systems & Technologies
 * Copyright (c) 2023 Singapore Institute of Technology
 * 
 */

/*
 * Add event listener to the document object to fire when
 * the document is fully loaded. From here, execute any
 * code that should run when the DOM is ready, such as
 * adding additional event listners, etc.
 * 
 * Alternatively, if using jQuery, you can take advantage of the
 * $(document).ready() method.
 */
document.addEventListener("DOMContentLoaded", function ()
{
    // Code to be executed when the DOM is ready (i.e. the document is fully loaded)...

    // Call our helper function to register additional event listners.
    // You could just write the code here, but it's much better to put
    // it in a function so it's more maintainable and easier to debug.
    registerEventListeners();

    // Any other initialization can go here...

});

/*
 * registerEventListeners()
 * 
 * This function tells the browser three things: 1) which element(s) we wish to
 * monitor for events, 2) which events we are interested in (e.g. mouse click,
 * mouse move, keyboard, etc.), and 3) what to do when the event fires.
 * 
 * This example uses pure JavaScript. If using jQuery, you can set event
 * listeners in one line of code, e.g. $(selector).click(funct).
 */
function registerEventListeners()
{
    // This demonstrates how to select a single element by ID in JavaScript
    // (this is why ID attributes must be unique and never duplicated - otherwise
    // the browser would not know which element you're referring to).
    var banner = document.getElementById("id-banner");

    // It's a good idea to check that the object is not null before using it!
    if (banner !== null)
    {
        // Now we have a valid object from the DOM corresponding to a specific img
        // element, stored in the variable banner. We just need to call the
        // addEventListener() method on it to tell the brower to listen for
        // mouse click events, and when that event fires, call the toggleCaption()
        // function.
        banner.addEventListener("click", toggleCaption);
    }

    // The second demonstration shows how to get multiple elements with one
    // function call. In this example, we'll get ALL elements that have the
    // class attribute logo.
    var logos = document.getElementsByClassName("logo");

    // Again, check to make sure the returned object is not null, and also
    // check that the array is not empty (this would indicate there aren't any
    // elements with that class).
    if (logos !== null && logos.length > 0)
    {
        // Ok the array looks valid, so we'll do same as in the first example
        // except we need to iterate through the array and do it for each
        // element.
        for (var i = 0; i < logos.length; i++)
        {
            var logo = logos[i];
            logo.addEventListener("click", toggleCaption);

            // Note that we're using the same function, toggleCaption(), to
            // handle events from both the banner image and the logo images,
            // since the desired behavior is the same. But you could just as
            // easily use different functions.
        }
    }
    else
    {
        console.log("No logo images found.");
    }

    // You can register any other event listeners here...
}


/*
 * toggleCaption()
 * 
 * This function handles the showing (creation) and hiding (removal) of the
 * image captions, in response to the user clicking on one of the images.
 * 
 * In this example, we dynamically create the new <figcaption> element and add
 * it to the DOM on the first click, then remove it on the next click,
 * effectively toggling the caption on and off.
 */
function toggleCaption(e)
{
    // Something to highlight here is the optional 'e' parameter that event
    // handler functions can make use of. This is an "event" object that has
    // several useful properties and methods. For example, we can use the
    // e.currentTarget or e.target property to get a reference to whichever
    // element was the source of this event. To see this in action, turn on
    // your browser's debugging/developer mode, switch to Console view, and
    // observe the output from the following statements:
    console.log("e.target.title: " + e.target.title);
    console.log("e.currentTarget.title: " + e.currentTarget.title);

    // There is a subtle difference between e.target and e.currentTarget,
    // which you can read about at: https://www.w3schools.com/jsref/event_target.asp

    // Yet another way to reference the element that fired this event is through
    // the "this" reference:
    console.log("this.title: " + this.title);

    // Now that we know how to access the element that fired this 'click' event,
    // we can proceed with the "toggle" operation. The logic here is simple:
    // check to see if the corresponding caption for this image (the one that
    // fired the event, i.e. the one clicked on by the user) is already showing
    // or not. If it is, we remove it, if it's not, we create it. Easy peasy!

    // We use a little trick here, which is to repurpose the 'alt' attribute of
    // the <img> element as the unique ID of the <figcaption> element. That way
    // no matter which image is clicked, our code should work nicely. Note that
    // this requires setting the 'alt' attributes correctly in the HTML file.
    var idCaption = e.target.alt;
    var caption = document.getElementById(idCaption);

    if (caption === null)
    {
        // caption is null, meaning it is toggled off (doesn't exist currently),
        // so let's create it:
        caption = document.createElement("figcaption");

        // Set the ID of the newly created element so that next time the
        // image is clicked, we can remove it:
        caption.id = idCaption;

        // Now set the text contents for the caption. Again we'll take the easy
        // way and steal the 'title' attribute for this:
        caption.innerText = e.target.title;

        // If desired, you could set any other attributes of the element here,
        // such as the class.

        // Finally, the new element must be added to the DOM - creating it
        // alone is not enough. There are a few functions you can use to add
        // an element to the DOM - we'll use insertAdjacentElement() since this
        // inserts it as a sibling of the <img> element that fired this event.
        // This is appropriate for <figcaption> elements, since they should
        // come after the <img> but nested within the parent <figure> element.
        e.target.insertAdjacentElement("afterend", caption);
    }
    else
    {
        // The caption is already showing, so remove it. Note that the remove()
        // method may not be supported on older browsers such as I.E. If using
        // jQuery, you can use the $(selector).remove() method instead, which
        // checks for older browsers.
        caption.remove();
    }
}
