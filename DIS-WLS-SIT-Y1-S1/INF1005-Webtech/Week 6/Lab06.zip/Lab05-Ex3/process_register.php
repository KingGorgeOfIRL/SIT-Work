<!DOCTYPE html>
<html lang="en">
    <?php include "inc/head.inc.php";?>
    <body>
        <?php include "inc/nav.inc.php";?>
        <main class="container">
            <?php
            $email = $errorMsg = "";
            $success = true;
            if (empty($_POST["email"]) || empty($_POST["pwd"]))
            {
            $errorMsg .= "Email and Password is required.<br>";
            $success = false;
            }
            else
            {
            $email = sanitize_input($_POST["email"]);
            $password = $_POST["pwd"];
            $password_confirm = $_POST["pwd_confirm"];
            $fname = sanitize_input($_POST["fname"]);
            $lname = sanitize_input($_POST["lname"]);
            // Additional check to make sure e-mail address is well-formed.
            if (!filter_var($email, FILTER_VALIDATE_EMAIL))
            {
                $errorMsg .= "Invalid email format.";
                $success = false;
            }
            if ($password != $password_confirm){
                $errorMsg .= "Passwords do not match.";
                $success = false;
            }
            $password = password_hash($_POST["pwd"],PASSWORD_DEFAULT);
            }
            if ($success)
            {
            echo "<h4>Registration successful!</h4>";
            echo "<p>Thank you for signing up, " .$fname." ".$lname. "</p>";
            echo "<div class='mb-3'><button class='btn btn-primary' href='#home' id='success-button'>Log-in</button></div>";
            }
            else
            {
            echo "<h4>An input error was detected:</h4>";
            echo "<p>" . $errorMsg . "</p>";
            echo "<div class='mb-3'><button class='btn btn-secondary' href='/register.php'>Return to Sign Up</button></div>";
            }
            /*
            * Helper function that checks input for malicious or unwanted content.
            */
            function sanitize_input($data)
            {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
            }
            ?>
        </main>
        <?php
        include "inc/footer.inc.php";
        ?>
    </body>
</html>
