MSP-EXP430F5529LP Software Examples v1.02.00
Texas Instruments, Inc.


********************************************************************************
Welcome to the MSP-EXP430F5529LP LaunchPad!
********************************************************************************

In this package, you will find software examples and source codes that can help
you quickly get started in developing your own project.

Two example software projects are located in the 'Software' folder:
 1. OutOfBox_EmulStorageKeyboard  | Out-of-Box Demo source code
 2. SimpleUsbBackchannel          | USB communication via Backchannel UART
                                    Example source code
 
In addition, prebuilt TI-TXT images are located in 'Software/Binaries'. These
images are ready to be downloaded onto your LaunchPad using a free MSP430
programming interface, such as the included MSP430Flasher. Just run the
"Program Example.bat" to download the corresponding project to your LaunchPad!

You can also find various web links in the 'Documentation' folder pointing to
the Tool Page, Quick Start Guide, User's Guide and MSP430 USB Developers Package.

For more resources, be sure to visit http://www.ti.com/tool/MSP-EXP430F5529LP
Also checkout the Wiki page at http://processors.wiki.ti.com/index.php/MSP430F5529_LaunchPad


********************************************************************************
Revision History
********************************************************************************
Ver 1.02.00 - Mar 8th, 2014
- Updated release packages to distribute hardware and software files separately

Ver 1.01.00 - Jan 2nd, 2014
- Updated Hardware files to Revision 1.5

Ver 1.00.01 - October 09th, 2013
- Added Code Size limited project for emulStorageKeyboard
- Added new folder to include emulation tool driver and simpleUsbBackChannel driver

Ver 1.00.00 - August 27th, 2013
- Initial Release


********************************************************************************
Project File Listing
********************************************************************************
|--Readme.txt                      : This file
|--Documentation                   : Folder containing links to more resources
|--Drivers                         : Folder containing driver files
   |--emulation                    : Contains driver for MSP430 emulation tools
   |--SimpleUsbBackChannel         : Contains USB CDC driver for SimpleUsbBackChannel example
|--Software                        : Folder containing software examples
   |--OutOfBox_EmulStorageKeyboard : Out-of-Box Demo example source code
   |--SimpleUsbBackchannel         : USB communication via Backchannel UART example source code
   |--Binaries                     : Folder containing TI-TXT image files and
                                     MSP430Flasher