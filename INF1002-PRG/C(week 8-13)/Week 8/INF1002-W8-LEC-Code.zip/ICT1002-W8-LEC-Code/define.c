#define NUM_STUDENTS 140

int main() {

    int scores[NUM_STUDENTS];

    for (int i = 0; i <= NUM_STUDENTS; i++) {
        scores[i] = 0;
    }

    return 0;

}
