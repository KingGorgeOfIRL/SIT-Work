/*
 * A simple C program.
 */
#include <stdio.h>

int main() {

	printf("Hello world! abcdefg\n");

    printf("Hello world!     \n");

	return 0;

}
